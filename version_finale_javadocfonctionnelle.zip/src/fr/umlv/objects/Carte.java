package fr.umlv.objects;


/**
 * Declaration of the interface which is the super type of the types CarteDev and Tuile.
 * (It hasn't been well developped yet)
 * 
 * @author dylandejesus nathanbilingi
 */
public  interface Carte {
	//public Carte fromText(String line);
}
